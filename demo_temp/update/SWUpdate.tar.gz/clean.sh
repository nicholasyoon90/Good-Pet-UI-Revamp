#!/bin/bash

cd /etc/GOODinc
sudo rm -rf *
