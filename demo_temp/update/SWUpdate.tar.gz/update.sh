#!/bin/bash

cd /etc/GOODinc
sudo cp /system/rc.local /etc/rc.local
sudo mv SN /etc/SN
