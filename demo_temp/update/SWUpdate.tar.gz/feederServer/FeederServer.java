package feederServer;
import java.io.*;
import java.nio.*;
import java.nio.channels.*;
import java.net.*;
import java.util.*;
import java.text.SimpleDateFormat;


public class FeederServer {

	private static int serialNumber;
	private static TimeZone tZone = TimeZone.getTimeZone("EST");

	public static void main(String[] args) {

		BufferedReader snF = null;
		String serialNumberStr = "0";

		try { //this blurb of code just gets the local device's serial number
			snF = new BufferedReader(new FileReader("/etc/SN"));
			serialNumberStr = snF.readLine();
			serialNumber = Integer.parseInt(serialNumberStr);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (snF != null)snF.close();
			} catch (IOException ex) {//serial number cannot be found
				ex.printStackTrace();
				return;
			}
		}


		System.out.println("Good, Inc. Rpi FeederServer v2.0");
		System.out.println("This is Good, Inc. Petfeeder, serial number "+serialNumber);

		SimpleDateFormat sdf = new SimpleDateFormat ("EEE MMM dd HH:mm:ss z yyyy");
		String timeStamp = sdf.format(Calendar.getInstance().getTime());
		System.out.println(timeStamp);

		int port = 4444; //this is the default backend port for our system

		System.out.println("Contacting goodMaster Servers on port 4444... \n");



		String sPort = Integer.toString(port);
		String sIP = "pet.buygood.us";
		long startTime = System.currentTimeMillis();
		while (true) {
			ServerRequest serverConvo = new ServerRequest();
			String ubrR = serverConvo.getServerMessageBack(sIP, sPort, "update beacon request"); // ask master server to update feeder IP in the DB
			if (ubrR.contains("unknownhost")) {
				long nowD = (System.currentTimeMillis() - startTime)/1000;
				//System.out.println(nowD + "/300");
				if (nowD > 300) { //if connection has failed for over 5 minutes
					System.out.println("We have not had internet for over five minutes! Re-entering WooFi now...");
					sysExec("sudo python py/lifecycleCore.py keep");
					System.out.println("Internet connection has been restored!");
					startTime = System.currentTimeMillis();
				}
				continue;
			}
			if (ubrR == null) {
				continue;
			}
			if (ubrR.contains("send serial to master server")) {
				startTime = System.currentTimeMillis(); //reset failure timer
				String serialR = serverConvo.getServerMessageBack(sIP, sPort, Integer.toString(serialNumber)); // give master server the feeder IP
				if (serialR == null) {
					continue;
				}
				if (serialR.contains("schD")) { //the feeder wants to send us a new schedule!
					try {
						BufferedWriter schW = new BufferedWriter(new FileWriter("/etc/GOODinc/schedule.txt"));
						boolean notEmpty = serialR.contains(";");
						if (notEmpty) {
							String[] schLines = serialR.split(";");
							System.out.println(schLines.length);
							for (int i = 0; i<schLines.length; i=i+1) {
								System.out.println(schLines[i]+"\n");
								String[] lineElements = schLines[i].split("\t");
								schW.write(parseSchedule(lineElements));
								schW.newLine();
							}
						} else {
							schW.write("");
						}
						schW.close();
						sysExec("python setSchedule.py");
					} catch (IOException eio) {}
				} else if (serialR.contains("open bowl")) {
					sysExec("python py/drawer.py open");
				} else if (serialR.contains("close bowl")) {
					sysExec("python py/drawer.py close");
					String setcloseR = serverConvo.getServerMessageBack(sIP, sPort, "closed");
				} else if (serialR.contains("run auger")) {
					sysExec("python py/auger.py 2.5");
				} else if (serialR.contains("snack")) {
					sysExec("python py/auger.py 2.5");
					sysExec("python py/drawer.py open");
				} else if (serialR.contains("SWUpdate")) {
					try {
						sysExec("sudo sh clean.sh"); //delete everything
						URL website = new URL("http://pet.buygood.us/demo/update/SWUpdate.tar.gz");
						ReadableByteChannel rbc = Channels.newChannel(website.openStream());
						FileOutputStream fos = new FileOutputStream("SWUpdate.tar.gz");
						fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
						sysExec("sudo tar -xvzf SWUpdate.tar.gz"); //install new local software
						sysExec("sudo sh update.sh"); // system file maintenance
						BufferedReader swvF = null;
						String swv = "0";

						try { //this blurb of code just gets the local device's latest software version
							swvF = new BufferedReader(new FileReader("SWVersion"));
							swv = swvF.readLine();
							System.out.println("SWVersion="+swv);
						} catch (IOException e) {
							e.printStackTrace();
						} finally {
							try {
								if (swvF != null)swvF.close();
							} catch (IOException ex) {//serial number cannot be found
								ex.printStackTrace();
							}
						}
						if (swv != "0") {
							swv = "swv "+swv;
						}
						String setSWVersion = serverConvo.getServerMessageBack(sIP, sPort, swv);
						sysExec("sudo shutdown -r now");
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		//return;
	}

	private static String parseSchedule(String[] lineE) { //this method just strips the data from the schedule strings into lines that will be written to a text file
		String outputL = "";
		for (int j=0; j<lineE.length; j=j+1) {
			if (1 <= j && j <= 8) {
				String[] dayParts = lineE[j].split("=");
				if (dayParts[1].contains("true")) {
					outputL += dayParts[0] + "%";
				}
				if (j == 8) {
					outputL += "\t";
				}
			} else {
				outputL += lineE[j] + "\t";
			}
		}
		return outputL;
	}

	public static void sysExec(String cmd) {
		try {
			Process p = Runtime.getRuntime().exec(cmd);
			p.waitFor();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return;
	}
}
