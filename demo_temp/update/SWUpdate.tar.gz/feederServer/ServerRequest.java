// This class just sends and retrieves messages from a remote server
// Author:  Mark J. Solters

package feederServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class ServerRequest {

	protected Socket clientSocket = null;
	protected PrintWriter out	=	null;
	protected BufferedReader in = null;

	public String getServerMessageBack(String IP, String port, String messageText) {
		try {
			clientSocket = new Socket(IP, Integer.parseInt(port));
			clientSocket.setSoTimeout(240000); //client timeout for reading data is 4 minutes (server timeout is 3 minutes -- so even if server dies, the client will not hang)
			out = new PrintWriter(clientSocket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		} catch (UnknownHostException e) {
			System.err.print("."); // can't find host
			return "unknownhost";
    	       	} catch (IOException e) {
    	       		System.err.print("|"); // can't connect
    	       		return "ioexception";
    	       	}
            	
                String inputline, outputline;
                
		try {
			out.println(messageText);
			inputline=in.readLine();
                
			if (inputline!=null) {
				System.out.println("GOODinc Master Server says:  " + inputline);
			} else {
	                	//the client has a sent a null message, probably a ping request; ignore
			}
			//System.out.println("Closing socket connection to "+clientSocket.getInetAddress()+"\n");
			out.close();
			in.close();
			clientSocket.close();
			return inputline;
		} catch (IOException e) {
			e.printStackTrace();
		}
                return null;
	}
}
