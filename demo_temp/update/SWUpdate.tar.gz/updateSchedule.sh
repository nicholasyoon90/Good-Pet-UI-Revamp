cd /etc/GOODinc

#sudo python checkOnline.py
sudo python py/setSchedule.py

exit 0
