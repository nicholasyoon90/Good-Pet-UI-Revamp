cd /etc/GOODinc

sudo java feederServer.FeederServer &

exit 0
