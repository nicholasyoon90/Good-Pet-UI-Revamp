import spidev

spi = spidev.SpiDev()
spi.open(0,0)

def get_adc(channel):
	if((channel > 1) or (channel < 0)):
		return -1

	r = spi.xfer2([1,(2+channel)<<6,0])

	ret = ((r[1]&31) << 6) + (r[2] >> 2)
	return ret

#while True:
print get_adc(0)
