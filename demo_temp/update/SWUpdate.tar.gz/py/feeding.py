import sys, os

weight = str(sys.argv[1])

#print weight
os.system('sudo python drawer.py close')
os.system('sudo python auger.py '+weight)
os.system('sudo python drawer.py open')
