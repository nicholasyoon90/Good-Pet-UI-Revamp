import sys
import csv
import os
import subprocess
from subprocess import PIPE
import time
import socket

def listenForNewCredentials(timeT):
	newCred = False
	file = '/var/www/wifi.txt'
	with open(file, 'w+') as f:
		f.seek(0)
		f.truncate()
		f.close()

	pb = subprocess.Popen(['python', 'py/leds.py', 'b'])
	launch = time.time()
	while not newCred:
		if timeT is not 0:
			dT = time.time() - launch
			print dT, '/', timeT
			if dT > timeT:
				return None	
		with open(file, 'r+') as f:
			content = f.readlines()
			if len(content) > 0:
				for i,elem in enumerate(content):
					content[i]=elem.rstrip()
					
				newCred = True
				f.seek(0)
				f.truncate()
				f.close()
				
				ssidNew = content[0]
				# if there was a password, we must get that as well
				if len(content) == 2:
					pwNew = content[1]
					pb.terminate()
					return [ssidNew, pwNew]
				else:
					pb.terminate()
					return [ssidNew]
				
			else:
				f.close()				
				#print 'Waiting for user to input credentials at 192.168.42.2.'
	pb.terminate()
	return [ssidNew, pwNew]			
				
def resetNetwork():
	while True: #take the network down
		dP = subprocess.Popen(["invoke-rc.d", "networking", "stop"], stdout=PIPE)
		downResults = dP.communicate()[0]
		#print downResults
		if 'RTNETLINK' in downResults:
			continue
		else:
			break
	
	while True:  #bring the network up
		try:
			os.system('sudo rm /etc/GOODinc/temp.txt')
			os.system('sudo invoke-rc.d networking start > /etc/GOODinc/temp.txt')
			with open('temp.txt', 'r+') as f:
				content=f.readlines()
				#print content
				if 'RTNETLINK' in content:
					f.close()
					#os.system('sudo rm temp.txt')
					resetNetwork()
					break
				else:
					f.close()
					#os.system('sudo rm temp.txt')
					break
		except:
			continue

	while True: #this loop makes sure the Pi has the right static IP			
		wlanResults = subprocess.check_output("ifconfig wlan0", shell=True)
		print 'wlanresults=', wlanResults
		if '192.168.42.2' in wlanResults:
			print 'we have the right ip!'
			break
		else:
			resetNetwork()
			break
	#os.system('sudo /etc/init.d/apache2 restart')
	return

def checkOnline():
	dup = subprocess.call(['sudo', 'ping', '-c1', 'google.com'])
	if dup == 0:
		return True
	else:
		return False
	
				
def startBeacon():
	dhcpUp = False
	while not dhcpUp:  #this loop is a dhcp server daemon, makes sure server comes up
		(dhcpResults, err)  = subprocess.Popen(["sudo","service","isc-dhcp-server","start"], stdout=subprocess.PIPE).communicate()
		if 'failed' in dhcpResults:
			print 'isc-dhcp-server has failed, trying again!'
			resetNetwork()
			os.system('sudo service isc-dhcp-server stop')
		else:
			print 'isc-dhcp-server is up!'
			dhcpUp = True
	os.system("sudo hostapd -B /etc/hostapd/hostapd.conf")
	print 'beacon is up, here are the stats:'
	os.system('sudo iwconfig')
	os.system('ifconfig')
	os.system('sudo service isc-dhcp-server status')

def createNewWPA(credentials):
	os.system('sudo rm /etc/wpa_credentials.conf')
	print credentials, len(credentials)
	if len(credentials) > 1:
		wpaCreateCmd = 'sudo wpa_passphrase "'+credentials[0]+'" "'+credentials[1]+'" > /etc/wpa_credentials.conf'
		os.system(wpaCreateCmd)
	else:
		f = open('/etc/wpa_credentials.conf','w+')
		f.write('network={\n')
		f.write('priority=1\n')
		f.write('ssid="'+credentials[0]+'"\n')
		f.write('key_mgmt=NONE\n')
		f.write('}')
		f.close()
