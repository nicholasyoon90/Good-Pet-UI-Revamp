def getScheduleFromFile():
	file = '/etc/GOODinc/schedule.txt'
	with open(file, 'r+') as f:
		content = f.readlines()
		if len(content) > 0:
			for i,elem in enumerate(content):
				content[i]=elem.rstrip()
			f.close()
			return content[0:len(content)]
		else:
			return 'nerp'
