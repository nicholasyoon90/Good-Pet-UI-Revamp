from scheduleMod import *
import time, os


cronTasks = []
#cronTasks.append('* * * * * sudo sh /etc/GOODinc/updateSchedule.sh')


schData = getScheduleFromFile()
if schData == 'nerp':
	print 'no schedules!'
else:
	currentDay = time.strftime("%A").lower()
	print 'Today is', currentDay

	for i,elem in enumerate(schData):
		eventData = elem.split('\t')
		print 'eventData=', eventData
			
		#First we will parse time data, convert to 24-hr format
		eventTime = eventData[2].split('=')
		eventTime = eventTime[1]
	
		morning = eventData[3].split('=')
		morning = morning[1]

		amount = eventData[4].split('=')
		amount = amount[1]
	
		timeSplit = eventTime.split(':')
			
		hour = timeSplit[0]
		minute = timeSplit[1]
		
		if (hour == '12'):
			if ('false' in morning):
				hour = '12'
			else:
				hour = '0'
		else:
			if ('false' in morning):
				hour = str(int(hour) + 12)
		
			
		# Next we will convert the day of the week into a form
		# cronttab can understand
		day = eventData[1]
		dNum = []
		
		print day
		if ('sunday' in day):
			dNum.append('0')
		if ('monday' in day):
			dNum.append('1')
		if ('tuesday' in day):
			dNum.append('2')
		if ('wednesday' in day):
			dNum.append('3')
		if ('thursday' in day):
			dNum.append('4')
		if ('friday' in day):
			dNum.append('5')
		if ('saturday' in day):
			dNum.append('6')
		if ('everyday' in day):
			dNum = '*'
		
		dNumStr = '' #this code adds commands to separate days
		if (len(dNum) > 1):
			print dNum
			for n,elem in enumerate(dNum):
				if n==len(dNum)-1:
					dNumStr += elem
				else:
					dNumStr += elem + ','
			dNumStr = dNumStr.rstrip()
		else:
			dNumStr = dNum[0]

		cTask = minute+' '+hour+' * * '+dNumStr+' cd /etc/GOODinc && sudo python py/feeding.py '+amount
		print cTask #'There is a feeding today, at ', hour, ':', minute
		cronTasks.append(cTask)	
		
f = open('/etc/GOODinc/cronSchedule.txt', 'w')
for i, task in enumerate(cronTasks):
	f.write(task+'\n')
f.close()

os.system('sudo crontab /etc/GOODinc/cronSchedule.txt')
