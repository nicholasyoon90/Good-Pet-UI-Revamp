#	gOOD, iNC. petfeeder - version 2. - main lifecycle
#	author:	mark j. solters


import sys
import csv
import os
import subprocess
import networkModule
import time

cPres = sys.argv[1] #should the credentials be deleted if they don't work?
if cPres == 'delete':
	cPres = False
else:
	cPres = True

connecting = False #this variable determines whether we are evaluating credentials, or gathering them via WooFi beacon
try:
	with open('/etc/wpa_credentials.conf'):
		connecting = True
		pass
except IOError:
	print 'There are no pre-existing WiFi credentials, entering beacon mode.'



while True:
#if there is an old credentials file, we attempt to connect to it
	if connecting == True:	##################################################################
#		orange lights for chcking	##################################################################
		orangeLED = subprocess.Popen(['python', 'py/leds.py', 'o'])	
		networkModule.resetNetwork()
		print 'Evaluating WiFi credentials.'
		connectCredentials = "wpa_supplicant -Dwext -iwlan0 -c/etc/wpa_credentials.conf -B"
		releaseIP = "sudo dhclient wlan0 -r"
		getWirelessIP = "sudo dhclient wlan0"
		os.system('sudo /etc/init.d/hostapd stop') #stop access point, if running 
		os.system(connectCredentials)
	
		attempts = 0
		epsilon_attempts = 3
		stillAttempt = True
		while stillAttempt == True:
			print 'ip attempt',str(attempts+1),'of',epsilon_attempts
			print 'Releasing IP...'
			os.system(releaseIP)
			print 'acquiring IP...'
			os.system(getWirelessIP)
				
			wlanResults = subprocess.Popen("ifconfig wlan0", shell=True, stdout=subprocess.PIPE).communicate()[0] #print the output of the wireless connection
			print 'wlanresults=', wlanResults
			os.system('iwconfig')
			if 'inet addr' in wlanResults:
				if '192.168.42.2' not in wlanResults:
					print 'woohoo! internet connectivity!'
					with open('/etc/resolv.conf', 'r+') as rf:
						rf.seek(0)
						rf.truncate()
						rf.write('nameserver 8.8.8.8\n')
						rf.write('nameserver 8.8.4.4')
						rf.close()
						print 'Google Inc. Nameservers Configured'
					
					if networkModule.checkOnline():
						orangeLED.terminate()
						lr = subprocess.Popen(['python', 'py/leds.py', 'g']) # something long running
						os.system('ntpdate pool.ntp.org')
						os.system('sudo /etc/init.d/ntp start')
						lr.terminate()
						lw = subprocess.Popen(['python', 'py/leds.py', 'w'])								
						sys.exit()

			attempts = attempts+1
			if attempts == epsilon_attempts:
				stillAttempt = False
		print 'No IP after ',attempts,'attempts.  Perhaps the credentials are incorrect?  Returning to beaconMode.'
		orangeLED.terminate()
		redLED = subprocess.Popen(['python', 'py/leds.py', 'r']) # something long running
		
		##################################################################
		# credentials are bad --- red					####
		##################################################################
		
		print 'restarting network services....'
		
		if cPres == False:
			os.system('sudo rm /etc/wpa_credentials.conf')
		connecting = False

		os.system('sudo rm /var/www/SSID.txt')
		
		os.system('sudo pkill wpa_supplicant')		
		os.system('sudo dhclient -r')
		networkModule.resetNetwork()	
		redLED.terminate()
		continue
		






######################################################################
#		No WPA Credentials here! --> wOOfI bacon + e
#######################################################################
	else: #if theres no wpa_credentials we create the user login website
		#p = subprocess.Popen(['python', 'leds.py', 'b']) # something long running

		#os.system('sudo ifconfig wlan0 up')
		wP = subprocess.Popen('iwlist wlan0 scan', shell=True, stdout=subprocess.PIPE)
		wifiScanResults = wP.communicate()[0].split("\n")
		print wifiScanResults
		ssidList = []
		securityList = []
		strengthList = []
		os.system("sudo rm /var/www/SSID.txt") #delete file on the off-chance there is one (shouldn't be)
	
		for line in wifiScanResults:
			if "ESSID" in line:
				ssidList.append(line.split(":")[1])
	
			if "Encryption" in line:
				securityList.append(line.split(":")[1])
	
			if "Signal level" in line:
				strengthList.append(line.split("=")[2].split("/")[0])			
	
		f = open('/var/www/SSID.txt', 'w')
		for i, ssidi in enumerate(ssidList):
			print ssidList
			if len(ssidi)>2: #only save ssids that are not empty
				f.write(ssidi+',')
				f.write(securityList[i]+',')
				f.write(strengthList[i]+'\n')
		f.close()
	
		#now we have the SSID file.  from this point we go into beacon mode:
		networkModule.resetNetwork()
		os.system('sudo /etc/init.d/apache2 restart')
		print '\n Restarting WooFi services, current network configuration:'
		networkModule.startBeacon()
		while True:
			wS = subprocess.check_output('sudo ifconfig wlan0', shell=True)
			print 'WooFi is GOOD to go! \n \n \n'+wS
			if '192.168.42.2' in wS:
				break
			else:
				os.system('sudo ifconfig wlan0 192.168.42.2')
		#turn on webcam -- only for demo	
		#os.system('(cd /etc/GOODinc/mjpg-streamer/mjpg-streamer; exec ./mjpg_streamer -i "./input_uvc.so -n -f 35 -r 768x576" -o "./output_http.so -n -w ./www") &')
		results = None
		if cPres == True:
			results = networkModule.listenForNewCredentials(600)
		else:
			results = networkModule.listenForNewCredentials(0)
		if results is not None:
			networkModule.createNewWPA(results)
	
		#Delete local list of SSIDs
		os.system('sudo rm /var/www/SSID.txt')
		connecting = True
		#Delete AP Services
		os.system('sudo /etc/init.d/hostapd stop')
		os.system('sudo service isc-dhcp-server stop')
		os.system('sudo pkill hostapd')
		#Reset local interfaces and IPs
		os.system('sudo dhclient -r')
		networkModule.resetNetwork()
		continue #back to the beginning!
