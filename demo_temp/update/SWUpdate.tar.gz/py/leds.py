#run with additional parameter r,g,b,o, or off
#ie for red:
#sudo python leds.py r
#for green:
#sudo python leds.py g
#to turn off:
#sudo python leds.py off
import RPi.GPIO as gpio
import time
from sys import argv

script,param = argv

gpio.setmode(gpio.BCM)
gpio.setup(2,gpio.OUT)
gpio.setup(3,gpio.OUT)
gpio.setup(4,gpio.OUT)
#gpio.setWarnings(False)

if param == "r":
	gpio.output(2,gpio.LOW)
	gpio.output(3,gpio.HIGH)
	gpio.output(4,gpio.HIGH)
elif param == "b":
	gpio.output(2,gpio.HIGH)
	gpio.output(3,gpio.LOW)
	gpio.output(4,gpio.HIGH)
elif param == "g":
	gpio.output(2,gpio.HIGH)
	gpio.output(3,gpio.HIGH)
	gpio.output(4,gpio.LOW)
elif param == "o":
	gpio.output(2,gpio.LOW)
	gpio.output(3,gpio.HIGH)
	gpio.output(4,gpio.LOW)
elif param == "w":
	gpio.output(2,gpio.LOW)
	gpio.output(3,gpio.LOW)
	gpio.output(4,gpio.LOW)
elif param == "off":
	gpio.output(2,gpio.HIGH)
	gpio.output(3,gpio.HIGH)
	gpio.output(4,gpio.HIGH)


