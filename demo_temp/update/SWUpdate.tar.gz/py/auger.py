import os, sys
import RPi.GPIO as gpio
import time
from sys import argv
import spidev

gpio.setwarnings(False)
gpio.setmode(gpio.BCM)

gpio.setup(24, gpio.OUT)
gpio.setup(25, gpio.OUT)

spi = spidev.SpiDev()
spi.open(0,0)

#n = int(sys.argv[1]) #number of rotations

# EDITED BY ERIC TO DEPOSIT HALF OF ITS NORMAL FOOD
#c_c = float(sys.argv[1]) #food to dispense in cups
c_c = 0

time_spin = 5

#here is the linear fit to map sensor values to cups: s -> c
s_0 = 235 #sensor value with no food in the bowl
gamma = 1.5 #some non-zero number of cups
s_gamma = 100 #the sensor value with gamma cups in the bowl

alpha = gamma/(s_gamma - s_0)
beta = -alpha*s_0


# read SPI data from MCP3002 chip
def get_adc(channel):
	# Only 2 channels 0 and 1 else return -1
	if ((channel > 1) or (channel < 0)):
		return -1
           
        # Send start bit, sgl/diff, odd/sign, MSBF
        # channel = 0 sends 0000 0001 1000 0000 0000 0000
        # channel = 1 sends 0000 0001 1100 0000 0000 0000
        # sgl/diff = 1; odd/sign = channel; MSBF = 0
	r = spi.xfer2([1,(2+channel)<<6,0])
           
        # spi.xfer2 returns same number of 8 bit bytes
        # as sent. In this case, 3 - 8 bit bytes are returned
        # We must then parse out the correct 10 bit byte from
        # the 24 bits returned. The following line discards
        # all bits but the 10 data bits from the center of
        # the last 2 bytes: XXXX XXXX - XXXX DDDD - DDDD DDXX
	ret = ((r[1]&31) << 6) + (r[2] >> 2)
	cups = alpha * ret + beta
	return cups


#for x in range(0, n):
#	gpio.output(24, gpio.LOW)
#	gpio.output(25, gpio.HIGH)
#	time.sleep(2)
#	gpio.output(24, gpio.LOW)
#	gpio.output(25, gpio.LOW)

#	gpio.output(24, gpio.HIGH)
#	gpio.output(25, gpio.LOW)

#	time.sleep(0.25)

#	gpio.output(24, gpio.LOW)
#	gpio.output(25, gpio.LOW)


counter = 0 # 
f = 0.02 # how many seconds between each measurement
time_spun = 0

foo = True

if not foo:
	gpio.output(24, gpio.LOW)
	gpio.output(25, gpio.LOW)
while foo:
	if counter < 2: #if counter is less than 2 seconds keep pushing food
		gpio.output(24, gpio.LOW)
		gpio.output(25, gpio.HIGH)
		#cC = get_adc(0)
		#print cC, '/', c_c
		#if (get_adc(0) >= c_c): #stop the program, that's enough food!
		if (time_spun > time_spin):
			gpio.output(24, gpio.LOW)
			gpio.output(25, gpio.LOW)
			sys.exit()
		
		time_spun += f
		counter += f
		time.sleep(f)
	elif ((counter > 2) and (counter < 2.25)): # at the end of 2 seconds, run in reverse for a quarter of a second to clear food
		gpio.output(24, gpio.LOW)
		gpio.output(25, gpio.LOW)

		gpio.output(24, gpio.HIGH)
		gpio.output(25, gpio.LOW)
		counter += 0.25
		time.sleep(0.25)

	else: #counter must be greater than 2.25 seconds, reset cycle
		counter = 0
		gpio.output(24, gpio.LOW)
		gpio.output(25, gpio.LOW)
