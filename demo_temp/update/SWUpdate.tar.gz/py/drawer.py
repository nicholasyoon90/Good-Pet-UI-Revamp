#this program opens the drawer
# by willie and mark

import os, sys
import RPi.GPIO as gpio
import time
from sys import argv

openTime = 2.5 #time to open drawer in s
#holdTime = float(sys.argv[2]) #time to hold drawer open in s
movement = str(sys.argv[1])

#setup gpio bus
gpio.setwarnings(False)
gpio.setmode(gpio.BCM)

#setup drawer motors
gpio.setup(18, gpio.OUT)
gpio.setup(23, gpio.OUT)

#setup drawer sensor
gpio.setup(22, gpio.IN, pull_up_down=gpio.PUD_DOWN)

#initialize all pins
gpio.output(18, gpio.LOW)
gpio.output(23, gpio.LOW)

#############################################################

if 'open' in movement:
	gpio.output(18, gpio.HIGH)
	gpio.output(23, gpio.LOW)
	time.sleep(openTime)
	gpio.output(18, gpio.LOW)
	gpio.output(23, gpio.LOW)
elif 'close' in movement:
	while(gpio.input(22) == gpio.LOW):
		gpio.output(18, gpio.LOW)
		gpio.output(23, gpio.HIGH)
		time.sleep(15.0/1000.0)

	gpio.output(18, gpio.LOW)
	gpio.output(23, gpio.LOW)


#cleanup!!
gpio.output(18, gpio.LOW)
gpio.output(23, gpio.LOW)


